export class UserInfoRequest {
    customerId: number | undefined;
    initialCredits: number | undefined;
  }