export class Customer {
    
    customerId: number | undefined;
    name: string| undefined;
    surname: string| undefined;
}

